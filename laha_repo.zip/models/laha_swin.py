"""LAHA-Swin — LAHA module, attention zoo (SE/ECA/CBAM), SwinWithAttention, build_model, FocalLoss, make_loader
Extracted from the reference notebook; paths are placeholders, set them in config.py.
"""
import os, json, random, time, math, glob
from pathlib import Path
import numpy as np
import cv2
from PIL import Image
import torch, torch.nn as nn, torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import OneCycleLR
from torch.utils.data import DataLoader, Dataset
import timm
import albumentations as A
from albumentations.pytorch import ToTensorV2
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score, precision_score, recall_score
from sklearn.utils.class_weight import compute_class_weight
from contextlib import nullcontext
from config import *
from data.dataset import *

# ═══════════════════════════════════════════════════════════
#  ATTENTION MODÜLLERİ — LAHA (ours) + baseline'lar (CBAM/SE/ECA)
#  Ablation'da hepsi kullanılır
# ═══════════════════════════════════════════════════════════

class SEModule(nn.Module):
    """Squeeze-and-Excitation (Hu et al., 2018) — channel only."""
    def __init__(self, ch, reduction=16):
        super().__init__()
        mid = max(ch // reduction, 4)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(ch, mid, bias=False), nn.ReLU(True),
            nn.Linear(mid, ch, bias=False), nn.Sigmoid())

    def forward(self, x):
        B, C, _, _ = x.shape
        w = self.fc(self.pool(x).view(B, C)).view(B, C, 1, 1)
        return x * w


class ECAModule(nn.Module):
    """Efficient Channel Attention (Wang et al., 2020)."""
    def __init__(self, ch, k_size=3):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k_size,
                              padding=(k_size - 1) // 2, bias=False)
        self.sig = nn.Sigmoid()

    def forward(self, x):
        y = self.pool(x).squeeze(-1).transpose(-1, -2)  # (B, 1, C)
        y = self.conv(y).transpose(-1, -2).unsqueeze(-1)
        return x * self.sig(y)


class CBAMModule(nn.Module):
    """CBAM (Woo et al., 2018) — channel + spatial baseline."""
    def __init__(self, ch, reduction=16, k=7):
        super().__init__()
        mid = max(ch // reduction, 4)
        self.mlp = nn.Sequential(
            nn.Flatten(), nn.Linear(ch, mid, bias=False),
            nn.ReLU(True), nn.Linear(mid, ch, bias=False))
        self.spatial = nn.Conv2d(2, 1, k, padding=k // 2, bias=False)

    def forward(self, x):
        B, C, H, W = x.shape
        avg = F.adaptive_avg_pool2d(x, 1)
        mx  = F.adaptive_max_pool2d(x, 1)
        ca  = torch.sigmoid(self.mlp(avg) + self.mlp(mx)).view(B, C, 1, 1)
        x   = x * ca
        s_avg = x.mean(dim=1, keepdim=True)
        s_mx  = x.max(dim=1, keepdim=True).values
        sa    = torch.sigmoid(self.spatial(torch.cat([s_avg, s_mx], dim=1)))
        return x * sa


# ═══════════════════════════════════════════════════════════
#  LAHA — Lesion-Aware Hybrid Attention (NOVELTY)
# ═══════════════════════════════════════════════════════════
class LAHA(nn.Module):
    """
    Lesion-Aware Hybrid Attention.

    Katkılar:
      1) Multi-scale dilated spatial attention (1×1, 3×3 d=2, 5×5 d=3)
         → küçük pustullardan büyük lekelere tüm ölçekleri yakalar
      2) Gated channel calibration — feature-map istatistiklerine göre
         kanal ağırlıklarını öğrenir, gated fusion ile kontrol eder
      3) Residual skip — dikkat çıktısını alpha ile ölçekler, kimlik
         bilgisini korur (özellikle küçük datasetlerde regularizer etkisi)
    """
    def __init__(self, ch, reduction=16, alpha_init=0.5):
        super().__init__()
        mid = max(ch // reduction, 4)

        # Channel branch (gated)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.ch_fc = nn.Sequential(
            nn.Conv2d(ch, mid, 1, bias=False),
            nn.GELU(),
            nn.Conv2d(mid, ch, 1, bias=False))
        # Gate: hangi kanal istatistiğini ne kadar kullanalım
        self.ch_gate = nn.Conv2d(ch * 2, 2, 1, bias=True)

        # Multi-scale spatial branch
        self.sp_conv1 = nn.Conv2d(2, 1, kernel_size=1, bias=False)
        self.sp_conv3 = nn.Conv2d(2, 1, kernel_size=3,
                                  padding=2, dilation=2, bias=False)
        self.sp_conv5 = nn.Conv2d(2, 1, kernel_size=5,
                                  padding=6, dilation=3, bias=False)
        self.sp_fuse  = nn.Conv2d(3, 1, 1, bias=False)

        # Öğrenilebilir residual katsayısı
        self.alpha = nn.Parameter(torch.tensor(alpha_init))

    def forward(self, x):
        identity = x
        B, C, H, W = x.shape

        # ── Channel branch (gated) ──
        a = self.ch_fc(self.avg_pool(x))   # (B, C, 1, 1)
        m = self.ch_fc(self.max_pool(x))
        gate_in = torch.cat([a, m], dim=1)                    # (B, 2C, 1, 1)
        gates   = torch.softmax(self.ch_gate(gate_in), dim=1) # (B, 2, 1, 1)
        ch_attn = torch.sigmoid(gates[:, 0:1] * a + gates[:, 1:2] * m)
        x = x * ch_attn

        # ── Multi-scale spatial branch ──
        s_avg = x.mean(dim=1, keepdim=True)
        s_mx  = x.max(dim=1, keepdim=True).values
        s_cat = torch.cat([s_avg, s_mx], dim=1)  # (B, 2, H, W)
        s1 = self.sp_conv1(s_cat)
        s3 = self.sp_conv3(s_cat)
        s5 = self.sp_conv5(s_cat)
        sp_attn = torch.sigmoid(self.sp_fuse(torch.cat([s1, s3, s5], dim=1)))
        x = x * sp_attn

        # ── Residual ──
        return identity + self.alpha * (x - identity)


class LAHA_NoGate(nn.Module):
    """
    LAHA without learned gate (ablation variant).

    LAHA ile tek farkı: channel branch'te softmax gate kaldırıldı.
    Avg ve max pool çıktıları CBAM tarzı basit toplamla birleşir.
    Bu ablation gate'in izole katkısını ölçer.
    """
    def __init__(self, ch, reduction=16, alpha_init=0.5):
        super().__init__()
        mid = max(ch // reduction, 4)

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.ch_fc = nn.Sequential(
            nn.Conv2d(ch, mid, 1, bias=False),
            nn.GELU(),
            nn.Conv2d(mid, ch, 1, bias=False))
        # ch_gate YOK — basit toplam kullanılır

        # Multi-scale spatial branch (LAHA ile aynı)
        self.sp_conv1 = nn.Conv2d(2, 1, kernel_size=1, bias=False)
        self.sp_conv3 = nn.Conv2d(2, 1, kernel_size=3,
                                  padding=2, dilation=2, bias=False)
        self.sp_conv5 = nn.Conv2d(2, 1, kernel_size=5,
                                  padding=6, dilation=3, bias=False)
        self.sp_fuse  = nn.Conv2d(3, 1, 1, bias=False)

        self.alpha = nn.Parameter(torch.tensor(alpha_init))

    def forward(self, x):
        identity = x

        # ── Channel branch (NO gate — CBAM tarzı toplam) ──
        a = self.ch_fc(self.avg_pool(x))
        m = self.ch_fc(self.max_pool(x))
        ch_attn = torch.sigmoid(a + m)
        x = x * ch_attn

        # ── Multi-scale spatial branch ──
        s_avg = x.mean(dim=1, keepdim=True)
        s_mx  = x.max(dim=1, keepdim=True).values
        s_cat = torch.cat([s_avg, s_mx], dim=1)
        s1 = self.sp_conv1(s_cat)
        s3 = self.sp_conv3(s_cat)
        s5 = self.sp_conv5(s_cat)
        sp_attn = torch.sigmoid(self.sp_fuse(torch.cat([s1, s3, s5], dim=1)))
        x = x * sp_attn

        return identity + self.alpha * (x - identity)


ATTENTION_ZOO = {
    'none'        : None,
    'se'          : SEModule,
    'eca'         : ECAModule,
    'cbam'        : CBAMModule,
    'laha_nogate' : LAHA_NoGate,   # ablation: gate'i olmayan LAHA
    'laha'        : LAHA,          # ours (full)
}


# ═══════════════════════════════════════════════════════════
#  MODEL: Swin-Small + pluggable attention + MC-Dropout head
# ═══════════════════════════════════════════════════════════
class SwinWithAttention(nn.Module):
    def __init__(self, base_model, num_classes, attn_type='laha',
                 dropout_p=0.3):
        super().__init__()
        self.backbone = base_model
        feat_dim = self.backbone.num_features
        self.attn_type = attn_type

        attn_cls = ATTENTION_ZOO.get(attn_type)
        self.attn = attn_cls(feat_dim) if attn_cls is not None else nn.Identity()

        self.backbone.reset_classifier(0)
        self.dropout = nn.Dropout(p=dropout_p)    # MC-Dropout için
        self.head    = nn.Linear(feat_dim, num_classes)

    def forward(self, x):
        feat = self.backbone.forward_features(x)
        if feat.dim() == 4:                # (B, H, W, C) → (B, C, H, W)
            feat = feat.permute(0, 3, 1, 2).contiguous()
        elif feat.dim() == 3:              # (B, L, C) → (B, C, h, w)
            B, L, C = feat.shape
            h = int(round(L ** 0.5))
            feat = feat.reshape(B, h, h, C).permute(0, 3, 1, 2).contiguous()

        if feat.dim() == 4:
            feat = self.attn(feat)
            feat = feat.mean(dim=[2, 3])   # Global avg pool
        # else feat.dim()==2 → zaten pooled
        return self.head(self.dropout(feat))


class FocalLoss(nn.Module):
    def __init__(self, alpha=1.0, gamma=2.0, weight=None):
        super().__init__()
        self.alpha, self.gamma, self.weight = alpha, gamma, weight

    def forward(self, inp, tgt):
        ce = F.cross_entropy(inp, tgt, weight=self.weight, reduction='none')
        pt = torch.exp(-ce)
        return (self.alpha * (1 - pt) ** self.gamma * ce).mean()


def build_model(model_name=None, attn_type='laha',
                freeze_backbone=True, dropout_p=0.3):
    name = model_name or CFG.MODEL_NAME
    base = timm.create_model(name, pretrained=True, num_classes=0)
    model = SwinWithAttention(base, CFG.NUM_CLASSES,
                              attn_type=attn_type, dropout_p=dropout_p)
    if freeze_backbone:
        for p in model.backbone.parameters():
            p.requires_grad = False
        for p in model.attn.parameters():
            p.requires_grad = True
        for p in model.head.parameters():
            p.requires_grad = True
    else:
        for p in model.parameters():
            p.requires_grad = True

    total  = sum(p.numel() for p in model.parameters()) / 1e6
    train_ = sum(p.numel() for p in model.parameters() if p.requires_grad) / 1e6
    print(f'  Attention: {attn_type.upper()} | Toplam: {total:.1f}M | '
          f'Eğitilen: {train_:.1f}M')
    return model.to(DEVICE)


def make_loader(samples, tfm, shuffle, drop_last=False, batch_size=None):
    bs = batch_size or CFG.BATCH_SIZE
    nw = CFG.NUM_WORKERS
    return DataLoader(
        MaizeDataset(samples, tfm),
        batch_size=bs, shuffle=shuffle,
        num_workers=nw,
        pin_memory=CFG.PIN_MEMORY and DEVICE.type == 'cuda',
        drop_last=drop_last,
        persistent_workers=(nw > 0),
    )


print('✅ Attention modülleri (SE/ECA/CBAM/LAHA) + SwinWithAttention hazır.')
print('\n🧪 Sanity check: LAHA forward pass (bs=1, VRAM dostu)...')
_m = build_model(attn_type='laha', freeze_backbone=True)
_x = torch.randn(1, 3, CFG.IMG_SIZE, CFG.IMG_SIZE).to(DEVICE)
with torch.no_grad():
    _o = _m(_x)
print(f'  Output shape: {_o.shape}  (beklenen: [1, 4])')
assert _o.shape == (1, CFG.NUM_CLASSES)
del _m, _x, _o
if DEVICE.type == 'cuda': torch.cuda.empty_cache()
print('  ✅ OK')
