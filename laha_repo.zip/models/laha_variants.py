"""LAHA-Swin — structural ablation variants (component-wise ablation, Table 13).

Each class isolates one part of the LAHA module and keeps the learnable
residual scaling alpha. Register them into ATTENTION_ZOO to use with
build_model(attn_type=...).

    channel_only   : gated channel branch only (no spatial branch)
    spatial_single : spatial branch only, single 1x1 scale
    spatial_multi  : spatial branch only, full multi-scale (no channel branch)
    no_d2          : full LAHA with the d=2 (3x3) dilated branch removed
    no_d3          : full LAHA with the d=3 (5x5) dilated branch removed
"""
import torch, torch.nn as nn


class LAHA_ChannelOnly(nn.Module):
    def __init__(self, ch, reduction=16, alpha_init=0.5):
        super().__init__()
        mid = max(ch // reduction, 4)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.ch_fc = nn.Sequential(nn.Conv2d(ch, mid, 1, bias=False), nn.GELU(), nn.Conv2d(mid, ch, 1, bias=False))
        self.ch_gate = nn.Conv2d(ch * 2, 2, 1, bias=True)
        self.alpha = nn.Parameter(torch.tensor(alpha_init))
    def forward(self, x):
        identity = x
        a = self.ch_fc(self.avg_pool(x)); m = self.ch_fc(self.max_pool(x))
        gates = torch.softmax(self.ch_gate(torch.cat([a, m], dim=1)), dim=1)
        x = x * torch.sigmoid(gates[:, 0:1] * a + gates[:, 1:2] * m)
        return identity + self.alpha * (x - identity)


class LAHA_SpatialSingle(nn.Module):
    def __init__(self, ch, reduction=16, alpha_init=0.5):
        super().__init__()
        self.sp_conv1 = nn.Conv2d(2, 1, kernel_size=1, bias=False)
        self.alpha = nn.Parameter(torch.tensor(alpha_init))
    def forward(self, x):
        identity = x
        s = torch.cat([x.mean(1, keepdim=True), x.max(1, keepdim=True).values], dim=1)
        x = x * torch.sigmoid(self.sp_conv1(s))
        return identity + self.alpha * (x - identity)


class LAHA_SpatialMulti(nn.Module):
    def __init__(self, ch, reduction=16, alpha_init=0.5):
        super().__init__()
        self.sp_conv1 = nn.Conv2d(2, 1, 1, bias=False)
        self.sp_conv3 = nn.Conv2d(2, 1, 3, padding=2, dilation=2, bias=False)
        self.sp_conv5 = nn.Conv2d(2, 1, 5, padding=6, dilation=3, bias=False)
        self.sp_fuse = nn.Conv2d(3, 1, 1, bias=False)
        self.alpha = nn.Parameter(torch.tensor(alpha_init))
    def forward(self, x):
        identity = x
        s = torch.cat([x.mean(1, keepdim=True), x.max(1, keepdim=True).values], dim=1)
        sp = torch.sigmoid(self.sp_fuse(torch.cat([self.sp_conv1(s), self.sp_conv3(s), self.sp_conv5(s)], dim=1)))
        x = x * sp
        return identity + self.alpha * (x - identity)


class _LAHA_TwoBranch(nn.Module):
    """Full LAHA with one dilated branch removed (helper for no_d2 / no_d3)."""
    def __init__(self, ch, keep_kernel, keep_pad, keep_dil, reduction=16, alpha_init=0.5):
        super().__init__()
        mid = max(ch // reduction, 4)
        self.avg_pool = nn.AdaptiveAvgPool2d(1); self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.ch_fc = nn.Sequential(nn.Conv2d(ch, mid, 1, bias=False), nn.GELU(), nn.Conv2d(mid, ch, 1, bias=False))
        self.ch_gate = nn.Conv2d(ch * 2, 2, 1, bias=True)
        self.sp_conv1 = nn.Conv2d(2, 1, 1, bias=False)
        self.sp_keep = nn.Conv2d(2, 1, keep_kernel, padding=keep_pad, dilation=keep_dil, bias=False)
        self.sp_fuse = nn.Conv2d(2, 1, 1, bias=False)
        self.alpha = nn.Parameter(torch.tensor(alpha_init))
    def forward(self, x):
        identity = x
        a = self.ch_fc(self.avg_pool(x)); m = self.ch_fc(self.max_pool(x))
        gates = torch.softmax(self.ch_gate(torch.cat([a, m], 1)), 1)
        x = x * torch.sigmoid(gates[:, 0:1] * a + gates[:, 1:2] * m)
        s = torch.cat([x.mean(1, keepdim=True), x.max(1, keepdim=True).values], 1)
        x = x * torch.sigmoid(self.sp_fuse(torch.cat([self.sp_conv1(s), self.sp_keep(s)], 1)))
        return identity + self.alpha * (x - identity)


class LAHA_NoD2(_LAHA_TwoBranch):
    """d=2 (3x3) branch removed; keeps 1x1 and 5x5/d=3."""
    def __init__(self, ch, reduction=16, alpha_init=0.5):
        super().__init__(ch, keep_kernel=5, keep_pad=6, keep_dil=3, reduction=reduction, alpha_init=alpha_init)


class LAHA_NoD3(_LAHA_TwoBranch):
    """d=3 (5x5) branch removed; keeps 1x1 and 3x3/d=2."""
    def __init__(self, ch, reduction=16, alpha_init=0.5):
        super().__init__(ch, keep_kernel=3, keep_pad=2, keep_dil=2, reduction=reduction, alpha_init=alpha_init)


VARIANTS = {
    'channel_only':   LAHA_ChannelOnly,
    'spatial_single': LAHA_SpatialSingle,
    'spatial_multi':  LAHA_SpatialMulti,
    'no_d2':          LAHA_NoD2,
    'no_d3':          LAHA_NoD3,
}

def register(attention_zoo):
    """attention_zoo: the ATTENTION_ZOO dict from models.laha_swin."""
    attention_zoo.update(VARIANTS)
    return attention_zoo
