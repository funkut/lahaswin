# Data

Not redistributed here. Download and place under `data_maize_diseases/archive/`:

- **Maize Diseases v1.1** (Kaggle) → `archive/v1.1/{Common_Rust,Gray_Leaf_Spot,Healthy,Northern_Leaf_Blight}/` (12,310 images incl. tif/webp)
- **PlantVillage corn subset** → 3,852 images, same four classes

Set `LAHA_DATA` to the `archive` directory (see `config.py`).

`splits/` contains the exact fold indices used for every reported number, so the
data need only be present with the same file ordering produced by `load_dataset`
(sorted by class, then filename).
