"""LAHA-Swin — dataset loading and transforms
Extracted from the reference notebook; paths are placeholders, set them in config.py.
"""
import os, json, random, time, math, glob
from pathlib import Path
import numpy as np
import cv2
from PIL import Image
import torch, torch.nn as nn, torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import OneCycleLR
from torch.utils.data import DataLoader, Dataset
import timm
import albumentations as A
from albumentations.pytorch import ToTensorV2
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score, precision_score, recall_score
from sklearn.utils.class_weight import compute_class_weight
from contextlib import nullcontext
from config import *

def scan_class_dir(root: Path, class_names):
    cls_to_idx = {cls: i for i, cls in enumerate(class_names)}
    IMG_EXTS = {'.jpg','.jpeg','.png','.bmp','.tif','.tiff','.webp'}
    samples = []
    for cls in class_names:
        cls_dir = root / cls
        if not cls_dir.exists():
            print(f'  ⚠️  Bulunamadı: {cls_dir}')
            continue
        for img in cls_dir.rglob('*'):
            if img.suffix.lower() in IMG_EXTS:
                samples.append((str(img), cls_to_idx[cls]))
    return samples


def load_dataset(base_dir=None, max_samples=None, shuffle_seed=42, tag='primary'):
    root = Path(base_dir) if base_dir else CFG.V11_DIR
    all_samples = scan_class_dir(root, CFG.CLASS_NAMES)

    rng = random.Random(shuffle_seed)
    rng.shuffle(all_samples)

    if max_samples:
        per_class = max_samples // CFG.NUM_CLASSES
        counts = {i: 0 for i in range(CFG.NUM_CLASSES)}
        trimmed = []
        for path, lbl in all_samples:
            if counts[lbl] < per_class:
                trimmed.append((path, lbl))
                counts[lbl] += 1
        all_samples = trimmed
        print(f'  ✂️  [{tag}] {len(all_samples)} görüntüye kırpıldı ({per_class}/sınıf)')

    labels = [s[1] for s in all_samples]
    print(f'[{tag}] Toplam görüntü : {len(all_samples)}')
    for cls, idx in {c: i for i, c in enumerate(CFG.CLASS_NAMES)}.items():
        print(f'  {cls:<28}: {labels.count(idx)}')

    if not all_samples:
        raise FileNotFoundError(
            f'[{tag}] Hiç görüntü bulunamadı.\nRoot: {root}\n'
            f'CFG.BASE_DIR yolunu kontrol edin!')

    return np.array(all_samples, dtype=object), np.array(labels)


max_s = CFG.MAX_SAMPLES if CFG.DEMO_MODE else None
samples, labels = load_dataset(CFG.V11_DIR, max_s, CFG.SEED, tag='primary')

# External dataset (cross-dataset validation için — opsiyonel)
external_samples, external_labels = None, None
if CFG.EXTERNAL_DIR and Path(CFG.EXTERNAL_DIR).exists():
    external_samples, external_labels = load_dataset(
        CFG.EXTERNAL_DIR, None, CFG.SEED, tag='external')
    print(f'✅ External dataset yüklendi: {len(external_samples)} örnek')
else:
    print('ℹ️  External dataset atlandı (Cross-dataset test pas geçilecek)')


MEAN = [0.485, 0.456, 0.406]
STD  = [0.229, 0.224, 0.225]

train_tfm = A.Compose([
    A.Resize(CFG.IMG_SIZE, CFG.IMG_SIZE),
    A.HorizontalFlip(p=0.5),
    A.VerticalFlip(p=0.3),
    A.RandomRotate90(p=0.3),
    A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.1,
                       rotate_limit=15, p=0.4),
    A.OneOf([
        A.RandomBrightnessContrast(0.2, 0.2),
        A.HueSaturationValue(10, 20, 10),
        A.CLAHE(clip_limit=2.0),
    ], p=0.6),
    A.OneOf([
        A.GaussianBlur(blur_limit=(3, 5)),
        A.GaussNoise(var_limit=(10.0, 50.0)),
        A.ISONoise(),
    ], p=0.3),
    A.CoarseDropout(max_holes=8, max_height=16, max_width=16, p=0.2),
    A.Normalize(mean=MEAN, std=STD),
    ToTensorV2(),
])

val_tfm = A.Compose([
    A.Resize(CFG.IMG_SIZE, CFG.IMG_SIZE),
    A.Normalize(mean=MEAN, std=STD),
    ToTensorV2(),
])

minimal_tfm = A.Compose([
    A.Resize(CFG.IMG_SIZE, CFG.IMG_SIZE),
    A.HorizontalFlip(p=0.5),
    A.Normalize(mean=MEAN, std=STD),
    ToTensorV2(),
])


class MaizeDataset(Dataset):
    def __init__(self, samples, transform=None):
        self.samples   = samples
        self.transform = transform
        self.targets   = [s[1] for s in samples]

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        img = cv2.imread(path)
        if img is None:
            img = np.zeros((CFG.IMG_SIZE, CFG.IMG_SIZE, 3), dtype=np.uint8)
        else:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        if self.transform:
            img = self.transform(image=img)['image']
        return img, int(label)


print('✅ Transform ve Dataset hazır.')
