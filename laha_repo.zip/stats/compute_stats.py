"""LAHA-Swin — paired statistics from released out-of-fold prediction files.

Reproduces every p-value, effect size, discordant-pair count and fold-level
win/loss/tie record reported in Tables 12, 13 and 15 of the manuscript,
directly from results/*/ *_fold*.json.

Usage:  python stats/compute_stats.py            (writes stats/paired_tests.json + .md)

Conventions
- Reference model: results/main_LAHA (learnable-alpha full LAHA-Swin, 40E, broad group-aware folds).
- McNemar: exact binomial on pooled out-of-fold discordant pairs (both models use the
  same test_idx, so instance-level pairing is exact); continuity-corrected chi-square
  when discordant pairs >= 25.
- Wilcoxon: two-sided signed-rank over the ten fold-level macro-F1 pairs.
- Holm-Bonferroni: applied within each family (attention ablation, component
  ablation, Swin-family baselines) separately, as stated in each table caption.
- r: rank-biserial correlation of the fold-level differences (variant - reference).
- W/L/T: fold-level wins/losses/ties of the REFERENCE against the variant.
"""
import json, glob, os, sys
import numpy as np
from scipy.stats import wilcoxon, rankdata
from statsmodels.stats.contingency_tables import mcnemar
from sklearn.metrics import f1_score

ROOT = os.path.join(os.path.dirname(__file__), '..', 'results')

def load(folder, prefix):
    files = sorted(glob.glob(os.path.join(ROOT, folder, f'{prefix}_fold*.json')),
                   key=lambda p: int(''.join(c for c in os.path.basename(p).split('fold')[1] if c.isdigit())))
    rows = [json.load(open(f)) for f in files]
    assert len(rows) == 10, f'{folder}/{prefix}: expected 10 folds, found {len(rows)}'
    return rows

def fold_f1(rows):
    return np.array([f1_score(np.array(r['labels']), np.array(r['preds']), average='macro') for r in rows])

def pooled_correct(rows):
    N = sum(len(r['labels']) for r in rows)
    pg = np.full(N, -1, int); lg = np.full(N, -1, int)
    for r in rows:
        ti = np.array(r['test_idx'], int)
        pg[ti] = np.array(r['preds'], int); lg[ti] = np.array(r['labels'], int)
    assert (pg >= 0).all(), 'test_idx does not cover every sample'
    return pg == lg

def holm(pvals):
    idx = np.argsort(pvals); m = len(pvals); adj = np.zeros(m); run = 0.0
    for rank, i in enumerate(idx):
        a = min(1.0, (m - rank) * pvals[i]); run = max(run, a); adj[i] = run
    return adj

def paired(ref_rows, var_rows):
    rf1, vf1 = fold_f1(ref_rows), fold_f1(var_rows)
    rc, vc = pooled_correct(ref_rows), pooled_correct(var_rows)
    ref_only = int(np.sum(rc & ~vc)); var_only = int(np.sum(~rc & vc))
    both = int(np.sum(rc & vc)); neither = int(np.sum(~rc & ~vc))
    n_disc = ref_only + var_only
    mcn = mcnemar([[both, ref_only], [var_only, neither]], exact=(n_disc < 25), correction=True).pvalue
    try: wil = wilcoxon(rf1, vf1, alternative='two-sided').pvalue
    except ValueError: wil = 1.0
    d = vf1 - rf1; nz = d[np.abs(d) > 1e-9]
    if len(nz):
        rk = rankdata(np.abs(nz)); r = float((rk[nz > 0].sum() - rk[nz < 0].sum()) / rk.sum())
    else: r = 0.0
    dr = rf1 - vf1
    wlt = [int(np.sum(dr > 1e-9)), int(np.sum(dr < -1e-9)), int(np.sum(np.abs(dr) <= 1e-9))]
    rng = np.random.default_rng(42)
    boot = np.array([rng.choice(vf1, 10, replace=True).mean() for _ in range(10000)])
    return dict(f1_mean=float(vf1.mean()), f1_std=float(vf1.std()),
                ci95=[float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))],
                delta=float(vf1.mean() - rf1.mean()),
                mcnemar_raw=float(mcn), wilcoxon_raw=float(wil), rank_biserial=r,
                discordant_ref_only=ref_only, discordant_var_only=var_only,
                ref_win_loss_tie=wlt, fold_f1=[float(x) for x in vf1])

FAMILIES = {
    'attention_ablation': [('SE','attention_ablation','se'), ('ECA','attention_ablation','eca'), ('CBAM','attention_ablation','cbam')],
    'component_ablation': [
        ('No attention (backbone) = fixed alpha 0.00','fixed_alpha','alpha_0_00'),
        ('Channel-only attention','component_ablation','channel_only'),
        ('Spatial-only, single-scale','component_ablation','spatial_single'),
        ('Spatial-only, multi-scale','component_ablation','spatial_multi'),
        ('LAHA without d=2 branch','component_ablation','no_d2'),
        ('LAHA without d=3 branch','component_ablation','no_d3'),
        ('LAHA fixed-sum (no gate)','nogate','nogate'),
        ('Fixed alpha 0.00','fixed_alpha','alpha_0_00'),
        ('Fixed alpha 0.50','fixed_alpha','alpha_0_50'),
        ('Fixed alpha 1.00','fixed_alpha','alpha_1_00')],
    'swin_family_baselines': [('Swin-Tiny','baselines_optB','swin_tiny'), ('Swin-Small','baselines_optB','swin_small')],
}

def main():
    ref = load('main_LAHA', 'laha')
    ref_f1 = fold_f1(ref)
    out = {'reference': {'name': 'LAHA-Swin learnable alpha (full), 40E, broad group-aware folds',
                         'f1_mean': float(ref_f1.mean()), 'f1_std': float(ref_f1.std()),
                         'fold_f1': [float(x) for x in ref_f1]}, 'families': {}}
    md = ['# Paired statistics (LAHA-Swin reference vs. each variant)\n',
          f"Reference macro F1 = {ref_f1.mean():.4f} +/- {ref_f1.std():.4f}\n"]
    for fam, members in FAMILIES.items():
        rows = {}
        for label, folder, prefix in members:
            rows[label] = paired(ref, load(folder, prefix))
        labels = list(rows)
        mh = holm([rows[l]['mcnemar_raw'] for l in labels]); wh = holm([rows[l]['wilcoxon_raw'] for l in labels])
        for i, l in enumerate(labels):
            rows[l]['mcnemar_holm'] = float(mh[i]); rows[l]['wilcoxon_holm'] = float(wh[i])
        out['families'][fam] = rows
        md.append(f'\n## {fam} (Holm family size = {len(labels)})\n')
        md.append('| Variant | F1 | delta | McN raw | McN Holm | Wilc raw | Wilc Holm | r | disc ref/var | ref W/L/T |')
        md.append('|---|---|---|---|---|---|---|---|---|---|')
        for l in labels:
            v = rows[l]
            md.append(f"| {l} | {v['f1_mean']:.4f} +/- {v['f1_std']:.4f} | {v['delta']:+.4f} | {v['mcnemar_raw']:.3f} | {v['mcnemar_holm']:.3f} | {v['wilcoxon_raw']:.3f} | {v['wilcoxon_holm']:.3f} | {v['rank_biserial']:+.2f} | {v['discordant_ref_only']}/{v['discordant_var_only']} | {'/'.join(map(str, v['ref_win_loss_tie']))} |")
    here = os.path.dirname(os.path.abspath(__file__))
    json.dump(out, open(os.path.join(here, 'paired_tests.json'), 'w'), indent=2)
    open(os.path.join(here, 'paired_tests.md'), 'w').write('\n'.join(md) + '\n')
    print('\n'.join(md))

if __name__ == '__main__':
    main()
