"""LAHA-Swin — train_one_fold (primary 40-epoch protocol) and _quick_train (20-epoch SOTA/ablation protocol)
Extracted from the reference notebook; paths are placeholders, set them in config.py.
"""
import os, json, random, time, math, glob
from pathlib import Path
import numpy as np
import cv2
from PIL import Image
import torch, torch.nn as nn, torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import OneCycleLR
from torch.utils.data import DataLoader, Dataset
import timm
import albumentations as A
from albumentations.pytorch import ToTensorV2
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score, precision_score, recall_score
from sklearn.utils.class_weight import compute_class_weight
from contextlib import nullcontext
from config import *
from data.dataset import *
from models.laha_swin import *

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
def measure_speed(model, device, n_warmup=20, n_test=100):
    model.eval(); d = torch.randn(1, 3, CFG.IMG_SIZE, CFG.IMG_SIZE, device=device)
    with torch.no_grad():
        for _ in range(n_warmup): _ = model(d)
    if device.type == 'cuda': torch.cuda.synchronize()
    t0 = time.perf_counter()
    with torch.no_grad():
        for _ in range(n_test): _ = model(d)
    if device.type == 'cuda': torch.cuda.synchronize()
    return (time.perf_counter() - t0) / n_test * 1000

def _make_scaler():
    use = CFG.USE_AMP and DEVICE.type == 'cuda'
    try:
        return torch.amp.GradScaler('cuda', enabled=use)
    except (TypeError, AttributeError):
        return torch.cuda.amp.GradScaler(enabled=use)


def _autocast_ctx():
    if not (CFG.USE_AMP and DEVICE.type == 'cuda'):
        return nullcontext()
    try:
        return torch.autocast(device_type='cuda')
    except TypeError:
        return torch.cuda.amp.autocast()


def train_one_fold(fold_idx, train_samples, val_samples, test_samples,
                    attn_type='laha'):
    set_all_seeds(CFG.SEED + fold_idx)  # Fold'a özgü seed (reproducibility)

    print(f'\n{"+" * 60}')
    print(f'  FOLD {fold_idx+1}/{CFG.N_FOLDS} — attn={attn_type.upper()}')
    print(f'  Train:{len(train_samples)} | Val:{len(val_samples)} | Test:{len(test_samples)}')
    print(f'{"+" * 60}')

    train_dl = make_loader(train_samples, train_tfm, shuffle=True, drop_last=True)
    val_dl   = make_loader(val_samples,   val_tfm,   shuffle=False)
    test_dl  = make_loader(test_samples,  val_tfm,   shuffle=False)

    # Güvenlik: drop_last yüzünden batch kalmayabilir
    if len(train_dl) == 0:
        print('  ⚠️  Train batch = 0 (batch_size çok büyük, drop_last=True). '
              'drop_last=False ile devam ediliyor.')
        train_dl = make_loader(train_samples, train_tfm,
                                shuffle=True, drop_last=False)

    train_labels = [s[1] for s in train_samples]
    cw = compute_class_weight('balanced',
                              classes=np.arange(CFG.NUM_CLASSES),
                              y=train_labels)
    cw_tensor = torch.tensor(cw, dtype=torch.float32, device=DEVICE)
    print(f'  Sınıf ağırlıkları: {np.round(cw, 3)}')

    model = build_model(attn_type=attn_type, freeze_backbone=True)
    criterion = FocalLoss(alpha=1.0, gamma=2.0, weight=cw_tensor)

    optimizer = optim.AdamW(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=CFG.LR, weight_decay=CFG.WEIGHT_DECAY)
    scheduler = OneCycleLR(
        optimizer, max_lr=CFG.LR,
        steps_per_epoch=len(train_dl),
        epochs=CFG.EPOCHS,
        pct_start=min(0.3, max(0.05, CFG.WARMUP_EPOCHS / max(CFG.EPOCHS, 1))),
        anneal_strategy='cos')

    scaler = _make_scaler()

    best_f1, pat, best_ckpt = 0.0, 0, CFG.OUTPUT_DIR / f'fold{fold_idx+1}_best.pth'
    history = {k: [] for k in ['train_loss', 'val_loss',
                                'train_acc', 'val_acc', 'val_f1']}

    for epoch in range(1, CFG.EPOCHS + 1):
        # Progressive unfreezing
        if epoch == CFG.WARMUP_EPOCHS + 1 and epoch <= CFG.EPOCHS:
            for p in model.parameters():
                p.requires_grad = True
            optimizer = optim.AdamW(model.parameters(),
                                    lr=CFG.LR * 0.1,
                                    weight_decay=CFG.WEIGHT_DECAY)
            scheduler = OneCycleLR(
                optimizer, max_lr=CFG.LR * 0.1,
                steps_per_epoch=len(train_dl),
                epochs=CFG.EPOCHS - epoch + 1,
                anneal_strategy='cos')
            print('  ✅ Tüm katmanlar açıldı (progressive unfreeze).')

        # ── TRAIN ──
        model.train()
        tr_loss = tr_cor = tr_tot = 0
        optimizer.zero_grad(set_to_none=True)

        pbar = tqdm(enumerate(train_dl), total=len(train_dl),
                    desc=f'F{fold_idx+1} Ep{epoch:02d}/{CFG.EPOCHS}',
                    leave=False, ncols=95)

        for step, (imgs, lbls) in pbar:
            imgs = imgs.to(DEVICE, non_blocking=True)
            lbls = lbls.to(DEVICE, non_blocking=True)

            with _autocast_ctx():
                out  = model(imgs)
                loss = criterion(out, lbls) / CFG.ACCUM_STEPS

            scaler.scale(loss).backward()
            bs = imgs.size(0)
            tr_loss += loss.item() * CFG.ACCUM_STEPS * bs
            tr_cor  += (out.argmax(1) == lbls).sum().item()
            tr_tot  += bs

            if (step + 1) % CFG.ACCUM_STEPS == 0 or (step + 1) == len(train_dl):
                scaler.unscale_(optimizer)
                nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler.step(optimizer); scaler.update()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)

            if CFG.EMPTY_CACHE and DEVICE.type == 'cuda' and (step + 1) % 50 == 0:
                torch.cuda.empty_cache()

        # ── VAL ──
        model.eval()
        v_loss = v_cor = v_tot = 0
        v_p, v_l = [], []
        with torch.no_grad():
            for imgs, lbls in val_dl:
                imgs = imgs.to(DEVICE, non_blocking=True)
                lbls = lbls.to(DEVICE, non_blocking=True)
                out  = model(imgs)
                loss = criterion(out, lbls)
                v_loss += loss.item() * imgs.size(0)
                pred = out.argmax(1)
                v_cor += (pred == lbls).sum().item()
                v_tot += imgs.size(0)
                v_p.extend(pred.cpu().numpy()); v_l.extend(lbls.cpu().numpy())

        tr_avg_loss = tr_loss / max(tr_tot, 1)
        tr_acc      = tr_cor / max(tr_tot, 1)
        v_avg_loss  = v_loss / max(v_tot, 1)
        v_acc       = v_cor / max(v_tot, 1)
        v_f1        = f1_score(v_l, v_p, average='macro', zero_division=0)

        history['train_loss'].append(tr_avg_loss)
        history['val_loss'].append(v_avg_loss)
        history['train_acc'].append(tr_acc)
        history['val_acc'].append(v_acc)
        history['val_f1'].append(v_f1)

        print(f'  Ep{epoch:02d}: TrLoss={tr_avg_loss:.4f} TrAcc={tr_acc:.4f} | '
              f'VLoss={v_avg_loss:.4f} VAcc={v_acc:.4f} VF1={v_f1:.4f}')

        if v_f1 > best_f1:
            best_f1, pat = v_f1, 0
            torch.save({'epoch': epoch, 'model_state_dict': model.state_dict(),
                        'val_f1': v_f1, 'attn_type': attn_type}, best_ckpt)
        else:
            pat += 1
            if pat >= CFG.PATIENCE:
                print(f'  ⏹  Erken durdurma (patience={CFG.PATIENCE})')
                break

    # ── TEST with best ──
    # weights_only=False → eski PyTorch sürümleriyle uyumlu
    try:
        ckpt = torch.load(best_ckpt, map_location=DEVICE, weights_only=False)
    except TypeError:
        ckpt = torch.load(best_ckpt, map_location=DEVICE)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()

    te_p, te_l, te_prob = [], [], []
    with torch.no_grad():
        for imgs, lbls in test_dl:
            imgs = imgs.to(DEVICE, non_blocking=True)
            lbls = lbls.to(DEVICE, non_blocking=True)
            out  = model(imgs)
            prob = F.softmax(out, dim=1)
            pred = prob.argmax(1)
            te_p.extend(pred.cpu().numpy())
            te_l.extend(lbls.cpu().numpy())
            te_prob.extend(prob.cpu().numpy())

    te_p    = np.array(te_p)
    te_l    = np.array(te_l)
    te_prob = np.array(te_prob)

    # Test indekslerini de sakla (out-of-fold ensemble için)
    result = {
        'fold'     : fold_idx + 1,
        'accuracy' : accuracy_score(te_l, te_p),
        'f1'       : f1_score(te_l, te_p, average='macro', zero_division=0),
        'precision': precision_score(te_l, te_p, average='macro', zero_division=0),
        'recall'   : recall_score(te_l, te_p, average='macro', zero_division=0),
        'preds'    : te_p,
        'labels'   : te_l,
        'probs'    : te_prob,
        'history'  : history,
        'attn_type': attn_type,
        'ckpt'     : str(best_ckpt),
    }

    del model
    if DEVICE.type == 'cuda': torch.cuda.empty_cache()

    print(f'  ✅ Fold {fold_idx+1} tamamlandı: F1={result["f1"]:.4f}')
    return result


SOTA_MODELS = {
    'ResNet-50'         : ('resnet50', False),
    'EfficientNet-B4'   : ('efficientnet_b4', False),
    'ViT-Small/16'      : ('vit_small_patch16_224', False),
    'ConvNeXt-Tiny'     : ('convnext_tiny', False),
    'Swin-Tiny'         : ('swin_tiny_patch4_window7_224', False),
    'Swin-Small (base)' : ('swin_small_patch4_window7_224', False),
    'Swin-Small + LAHA (Ours)': ('swin_small_patch4_window7_224', True),   # gerçek Ours
}


def _quick_train(model, train_dl, val_dl, test_dl,
                 use_focal=True, use_warmup=True, use_class_weight=True,
                 train_labels=None):
    if use_class_weight and train_labels is not None:
        cw = compute_class_weight('balanced',
                                  classes=np.arange(CFG.NUM_CLASSES),
                                  y=train_labels)
        cw_tensor = torch.tensor(cw, dtype=torch.float32, device=DEVICE)
    else:
        cw_tensor = None

    # train_dl boş ise fallback
    if len(train_dl) == 0:
        print('    ⚠️  Train batch = 0, drop_last kapatılıyor.')
        ds = train_dl.dataset
        train_dl = DataLoader(ds, batch_size=CFG.BATCH_SIZE, shuffle=True,
                              num_workers=CFG.NUM_WORKERS,
                              pin_memory=CFG.PIN_MEMORY and DEVICE.type == 'cuda',
                              drop_last=False,
                              persistent_workers=(CFG.NUM_WORKERS > 0))

    if use_warmup:
        # DOĞRU classifier dondurma — tüm timm mimarileri desteklenir
        try:
            classifier = model.get_classifier()
            clf_ids = {id(p) for p in classifier.parameters()}
        except Exception:
            clf_ids = set()
        for p in model.parameters():
            p.requires_grad = id(p) in clf_ids
        trainable = [p for p in model.parameters() if p.requires_grad]
        if not trainable:
            # get_classifier() boş döndü → hepsini eğit
            for p in model.parameters(): p.requires_grad = True
            trainable = list(model.parameters())
            use_warmup = False
        optimizer = optim.AdamW(trainable, lr=CFG.LR,
                                weight_decay=CFG.WEIGHT_DECAY)
        warmup_ep = max(1, CFG.QUICK_EPOCHS // 5)
    else:
        for p in model.parameters(): p.requires_grad = True
        optimizer = optim.AdamW(model.parameters(),
                                lr=CFG.LR * 0.1,
                                weight_decay=CFG.WEIGHT_DECAY)
        warmup_ep = 0

    criterion = (FocalLoss(alpha=1.0, gamma=2.0, weight=cw_tensor)
                 if use_focal else nn.CrossEntropyLoss(weight=cw_tensor))

    scheduler = OneCycleLR(
        optimizer,
        max_lr=CFG.LR * 0.1 if not use_warmup else CFG.LR,
        steps_per_epoch=len(train_dl),
        epochs=CFG.QUICK_EPOCHS, anneal_strategy='cos')
    scaler = _make_scaler()

    best_f1, best_state = 0.0, None

    for epoch in range(1, CFG.QUICK_EPOCHS + 1):
        if use_warmup and epoch == warmup_ep + 1:
            for p in model.parameters(): p.requires_grad = True
            optimizer = optim.AdamW(model.parameters(),
                                    lr=CFG.LR * 0.1,
                                    weight_decay=CFG.WEIGHT_DECAY)
            scheduler = OneCycleLR(
                optimizer, max_lr=CFG.LR * 0.1,
                steps_per_epoch=len(train_dl),
                epochs=CFG.QUICK_EPOCHS - epoch + 1,
                anneal_strategy='cos')

        model.train()
        optimizer.zero_grad(set_to_none=True)
        for step, (imgs, lbls) in enumerate(train_dl):
            imgs = imgs.to(DEVICE, non_blocking=True)
            lbls = lbls.to(DEVICE, non_blocking=True)
            with _autocast_ctx():
                loss = criterion(model(imgs), lbls) / CFG.ACCUM_STEPS
            scaler.scale(loss).backward()
            if (step + 1) % CFG.ACCUM_STEPS == 0 or (step + 1) == len(train_dl):
                scaler.unscale_(optimizer)
                nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler.step(optimizer); scaler.update()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)

        model.eval()
        v_p, v_l = [], []
        with torch.no_grad():
            for imgs, lbls in val_dl:
                v_p.extend(model(imgs.to(DEVICE, non_blocking=True))
                           .argmax(1).cpu().numpy())
                v_l.extend(lbls.numpy())
        vf = f1_score(v_l, v_p, average='macro', zero_division=0)
        if vf > best_f1:
            best_f1 = vf
            best_state = {k: v.detach().cpu().clone()
                          for k, v in model.state_dict().items()}

    if best_state is None:
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    model.load_state_dict({k: v.to(DEVICE) for k, v in best_state.items()})
    model.eval()

    te_p, te_l, te_prob = [], [], []
    with torch.no_grad():
        for imgs, lbls in test_dl:
            out  = model(imgs.to(DEVICE, non_blocking=True))
            prob = F.softmax(out, dim=1)
            te_p.extend(prob.argmax(1).cpu().numpy())
            te_l.extend(lbls.numpy())
            te_prob.extend(prob.cpu().numpy())

    speed = measure_speed(model, DEVICE) if DEVICE.type == 'cuda' else None
    if speed is None:
        speed = measure_speed(model, DEVICE, n_warmup=5, n_test=20)

    return {
        'accuracy' : accuracy_score(te_l, te_p),
        'f1'       : f1_score(te_l, te_p, average='macro', zero_division=0),
        'precision': precision_score(te_l, te_p, average='macro', zero_division=0),
        'recall'   : recall_score(te_l, te_p, average='macro', zero_division=0),
        'preds'    : np.array(te_p),
        'labels'   : np.array(te_l),
        'probs'    : np.array(te_prob),
        'speed_ms' : speed,
        'params_M' : sum(p.numel() for p in model.parameters()) / 1e6,
    }


def run_sota_comparison(samples, labels, shared_folds):
    print('=' * 65)
    print('  SOTA KARŞILAŞTIRMASI (shared folds, doğru warmup, drop_last)')
    print('=' * 65)

    comparison = {name: [] for name in SOTA_MODELS}

    for display_name, (timm_name, is_ours) in SOTA_MODELS.items():
        print(f'\n  ▶ {display_name}  ({timm_name}, ours={is_ours})')
        fold_f1s = []

        for fi, (trainval_idx, test_idx) in enumerate(shared_folds):
            set_all_seeds(CFG.SEED + fi)
            trainval = samples[trainval_idx].tolist()
            test_s   = samples[test_idx].tolist()
            tv_lbl   = labels[trainval_idx].tolist()

            try:
                tr_idx, va_idx = train_test_split(
                    range(len(trainval)), test_size=0.20,
                    stratify=tv_lbl, random_state=CFG.SEED + fi)
            except ValueError:
                tr_idx, va_idx = train_test_split(
                    range(len(trainval)), test_size=0.20,
                    random_state=CFG.SEED + fi)
            train_s = [trainval[i] for i in tr_idx]
            val_s   = [trainval[i] for i in va_idx]

            train_dl = make_loader(train_s, train_tfm, shuffle=True, drop_last=True)
            val_dl   = make_loader(val_s,   val_tfm,   shuffle=False)
            test_dl  = make_loader(test_s,  val_tfm,   shuffle=False)

            try:
                if is_ours:
                    # LAHA'lı Swin — gerçek 'Ours' satırı
                    model = build_model(model_name=timm_name, attn_type='laha',
                                        freeze_backbone=False)
                else:
                    model = timm.create_model(timm_name, pretrained=True,
                                              num_classes=CFG.NUM_CLASSES).to(DEVICE)
                res = _quick_train(model, train_dl, val_dl, test_dl,
                                   use_focal=True, use_warmup=True,
                                   use_class_weight=True,
                                   train_labels=[s[1] for s in train_s])
                fold_f1s.append(res['f1'])
                comparison[display_name].append(res)
                print(f'    Fold {fi+1}: F1={res["f1"]:.4f} | '
                      f'{res["speed_ms"]:.1f}ms | {res["params_M"]:.1f}M')
                del model
                if DEVICE.type == 'cuda': torch.cuda.empty_cache()
            except Exception as e:
                import traceback
                print(f'    ❌ HATA ({timm_name}, fold {fi+1}): {e}')
                traceback.print_exc()
                if DEVICE.type == 'cuda': torch.cuda.empty_cache()

        if fold_f1s:
            print(f'    → Ort. F1: {np.mean(fold_f1s):.4f} ± '
                  f'{np.std(fold_f1s):.4f}')

    return comparison


def plot_sota(comparison):
    names, f1m, f1s, sp, pr = [], [], [], [], []
    for n, folds in comparison.items():
        if not folds: continue
        names.append(n)
        f1m.append(np.mean([f['f1'] for f in folds]))
        f1s.append(np.std([f['f1'] for f in folds]))
        sp.append(np.mean([f['speed_ms'] for f in folds]))
        pr.append(np.mean([f['params_M'] for f in folds]))

    if not names:
        print('⚠️  SOTA sonucu yok.')
        return

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    colors = ['#E91E63' if 'Ours' in n else '#2196F3' for n in names]
    axes[0].barh(names, f1m, xerr=f1s, color=colors, alpha=0.85, capsize=4)
    axes[0].set_xlabel('Macro F1'); axes[0].set_xlim(max(0, min(f1m) - 0.05), 1.02)
    axes[0].set_title(f'SOTA Karşılaştırması ({CFG.N_FOLDS}-Fold CV)')
    for i, (m, s) in enumerate(zip(f1m, f1s)):
        axes[0].text(m + s + 0.001, i, f'{m:.4f}±{s:.4f}',
                     va='center', fontsize=9)
    axes[0].grid(axis='x', alpha=0.3)

    for i, n in enumerate(names):
        mk, sz = ('*', 250) if 'Ours' in n else ('o', 120)
        axes[1].scatter(sp[i], f1m[i], s=sz, color=colors[i], marker=mk, zorder=5)
        axes[1].annotate(n, (sp[i], f1m[i]),
                         textcoords='offset points', xytext=(5, 3), fontsize=8)
    axes[1].set_xlabel('Latency (ms/img)'); axes[1].set_ylabel('Macro F1')
    axes[1].set_title('Accuracy-Efficiency Trade-off (★ = Ours)')
    axes[1].grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(CFG.OUTPUT_DIR / 'sota_comparison.png', dpi=150)
    plt.show()
