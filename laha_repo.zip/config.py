"""LAHA-Swin — configuration and seeding
Extracted from the reference notebook; paths are placeholders, set them in config.py.
"""
import os, json, random, time, math, glob
from pathlib import Path
import numpy as np
import cv2
from PIL import Image
import torch, torch.nn as nn, torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import OneCycleLR
from torch.utils.data import DataLoader, Dataset
import timm
import albumentations as A
from albumentations.pytorch import ToTensorV2
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score, precision_score, recall_score
from sklearn.utils.class_weight import compute_class_weight
from contextlib import nullcontext

def set_all_seeds(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # Tam deterministik mod (biraz yavaşlatır ama Q1 için şart)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ['PYTHONHASHSEED'] = str(seed)


RUN_ID = datetime.now().strftime('%Y%m%d_%H%M%S')

_IS_WINDOWS = platform.system() == 'Windows'
_CUDA_OK    = torch.cuda.is_available()


class CFG:
    # ⚠️ BURAYA KENDİ VERİ YOLUNUZU GİRİN
    BASE_DIR     = Path(os.environ.get('LAHA_DATA', './data_maize_diseases/archive'))
    OUTPUT_DIR   = Path(os.environ.get('LAHA_OUT', './outputs'))

    # İkinci dataset (out-of-distribution validation için). Yoksa None bırakın.
    EXTERNAL_DIR = None   # örn: Path(r'.../plantdoc_maize')

    MODEL_NAME   = 'swin_small_patch4_window7_224'
    NUM_CLASSES  = 4
    IMG_SIZE     = 224
    CLASS_NAMES  = ['Common Rust', 'Gray Leaf Spot',
                    'Healthy', 'Northern Leaf Blight']

    # ───────────────────────────────────────────────────────────
    # MOD: DEMO / PROD
    # ───────────────────────────────────────────────────────────
    DEMO_MODE    = False      # True: hızlı ön test | False: Q1 tam çalışma

    # Hyperparametreler (Q1 için daha geniş)
    N_FOLDS      = 3 if DEMO_MODE else 10
    EPOCHS       = 3 if DEMO_MODE else 40        # ↑ Q1: daha fazla epoch
    BATCH_SIZE   = 4 if DEMO_MODE else 16
    ACCUM_STEPS  = 2 if DEMO_MODE else 4
    QUICK_EPOCHS = 3 if DEMO_MODE else 20        # ↑ Q1: SOTA adil eğitim
    MAX_SAMPLES  = 800 if DEMO_MODE else None

    # Windows'ta multi-worker sorunlu; Colab/Linux'ta GPU için 2 iyi bir değer
    NUM_WORKERS    = 0 if _IS_WINDOWS else (2 if _CUDA_OK else 0)
    LR             = 1e-4
    WEIGHT_DECAY   = 1e-2
    WARMUP_EPOCHS  = 3
    PATIENCE       = 8
    USE_AMP        = True
    # GPU'da pin_memory açık, CPU'da kapalı (anlamsız)
    PIN_MEMORY     = _CUDA_OK
    EMPTY_CACHE    = True

    # Data efficiency curve oranları
    DATA_FRACTIONS = [0.10, 0.25, 0.50, 1.00]

    # MC-Dropout
    MC_SAMPLES     = 30

    SEED           = 42


CFG.V10_DIR = CFG.BASE_DIR / 'v10'
CFG.V11_DIR = CFG.BASE_DIR / 'v11'
CFG.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

set_all_seeds(CFG.SEED)

mode_str = '🚀 DEMO' if CFG.DEMO_MODE else '🔬 PRODUCTION (Q1)'
print(f"Run ID     : {RUN_ID}")
print(f"Mod        : {mode_str}")
print(f"Seed       : {CFG.SEED}")
print(f"N_FOLDS    : {CFG.N_FOLDS} | EPOCHS: {CFG.EPOCHS}")
print(f"Output Dir : {CFG.OUTPUT_DIR.resolve()}")
print(f"Primary    : {CFG.V11_DIR} | exists: {CFG.V11_DIR.exists()}")
print(f"External   : {CFG.EXTERNAL_DIR}")
print(f"CUDA       : {_CUDA_OK} | NUM_WORKERS={CFG.NUM_WORKERS} | PIN_MEMORY={CFG.PIN_MEMORY}")
