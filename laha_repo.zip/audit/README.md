# Duplicate audit outputs

`group_aware_maize.json` / `group_aware_pv.json` (in `splits/`) hold the near-duplicate
pairs, the connected-component group ids, the original stratified folds and both
group-aware repair options (A: StratifiedGroupKFold; B: minimal repair — used).

Raw SHA-256 / dHash / pHash tables per image are large and are provided in the
Zenodo archive rather than in this repository.
